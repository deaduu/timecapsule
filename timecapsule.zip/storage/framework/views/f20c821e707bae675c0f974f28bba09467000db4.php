<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>404 - Not Found</title>
    <link rel="stylesheet" href="<?php echo e(asset('404/style.css')); ?>">

</head>

<body>
    <!-- partial:index.partial.html -->
    <div class="container">
        <div class="psyduck"></div>
    </div>
    <!-- partial -->

</body>

</html><?php /**PATH C:\Users\DeaDu\Desktop\timecapsule\resources\views/errors/404.blade.php ENDPATH**/ ?>